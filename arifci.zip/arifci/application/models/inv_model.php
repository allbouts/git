<?php
	/**
	* 
	*/
	class inv_model extends CI_Model
	{
		
		
		//ambil semua data barang
		function getAllData(){

			//dengan query
			//$hasil = $this->db->query('SELECT * FROM barang');

			//dengan active record
			//pilih field dalam table
			$this->db->select('*,golongan');
			//pilih asal table
			$this->db->from('barang');
			//apabila innerjoin
			$this->db->join('golongan','barang.idgol=golongan.idgol');
			//dengan where
			//$this->db->where('golongan.idgol','g01');

			$hasil=$this->db->get();
			return($hasil);
		}

		//ambil data barang berdasarkan id nya
		function getIdBrg($idbrg){
			$this->db->select('*');
			$this->db->from('barang');
			$this->db->where('idbrg',$idbrg);
			$hasil = $this->db->get();
			return $hasil;
		}

		//ambil data golongan yang akan dibinding ke combobox di form edit
		function getGol(){
			$hsl = $this->db->get('golongan');
			foreach ($hsl->result() as $row) {
				$hasil[$row->idgol] = $row->idgol."|".$row->golongan; //dibuat array supaya dicombobox bisa terlihat id beserta golongan nya
			}
			return($hasil);
		}

		//update data
		function update($barang,$idg){
			$this->db->where('idbrg',$idg);
			$id = $this->db->update('barang',$barang);
			return $id;
		}

		function delbrg($idbrg){
			$this->db->where('idbrg',$idbrg);
			$id = $this->db->delete('barang');
			return($id);
		}

		function savebrg($barang){
			$id = $this->db->insert('barang',$barang);
			return($id);
		}

		function get_page_list($limit,$offset){
			$this->db->select('*,golongan');
			$this->db->join('golongan','barang.idgol=golongan.idgol');
			$hsl = $this->db->get("barang",$limit,$offset);
			return($hsl);
		}

		function getCust(){
			$hsl = $this->db->get('customer');
			$hasil = array();
			foreach ($hsl->result() as $brs) {
				$hasil[$brs->idcust]=$brs->nmcust;
			}
			return($hasil);
		}

		function getBarang(){
			$hsl = $this->db->get('barang');
			foreach ($hsl->result() as $brs) {
				$hasil[$brs->idbrg]=$brs->nmbrg;
			}
			return($hasil);
		}

		function dttrans(){
			$this->db->select('*,tgl_trans,nmcust,nmbrg');
			//pilih asal table
			$this->db->from('transd');
			//apabila innerjoin
			$this->db->join('transaksi','transd.notrans=transaksi.notrans');
			$this->db->join('customer','transaksi.idcust=customer.idcust');
			$this->db->join('barang','transd.idbrg=barang.idbrg');
			$this->db->order_by('transd.notrans','asc');
			//dengan where
			//$this->db->where('golongan.idgol','g01');

			$hasil=$this->db->get();
			return($hasil);
		}
	}
?>