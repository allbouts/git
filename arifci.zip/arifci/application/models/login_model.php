<?php
	/**
	* 
	*/
	class login_model extends CI_Model
	{
		
		function m_aksi($data)
		{
			$this->db->select('*');
			$this->db->where('username',$data['username']);
			$this->db->where('password',$data['password']);
			$dt = $this->db->get('login');
			return($dt);
		}

		function getdata($data){
			$this->db->select('*');
			$this->db->where('username',$data);
			$dt = $this->db->get('login');
			return($dt);	
		}
	}
?>