<?php
	/**
	* 
	*/
	class simpan_model extends CI_Model
	{
		
		function saveh($data){
			$this->db->insert('transaksi',$data);
			$id = $this->db->insert_id();
			return(isset($id)) ? $id : false;
		}
		
		function saved($data){
			$this->db->insert('transd',$data);
		}
	}
?>