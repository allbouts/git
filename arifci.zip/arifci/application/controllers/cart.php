<?php 
	/**
	* 
	*/
	class cart extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			$this->load->helper(array('form','url'));
			//$this->load->library('cart');
			//$this->load->model('car_model');
			$data = $this->session->all_userdata();
			$un = $data['username'];
			if($un==''){
				redirect('login');
			}
		}

		function index(){
			$data['judul']="Data Transaksi";
			if(!$this->cart->contents()){
				$data['message']='<p>Transkasi Kosong .. !!</p>';
			}
			else{
				$data['message']=$this->session->flashdata('message');
			}
			//$this->load->view('header',$data);
			$this->load->view('vcart',$data);
			//$this->load->view('footer',$data);
		}

		function add(){
			$idcust = $this->input->post('idcust');
			$this->session->set_userdata('idcust',$idcust);
			$insert = array(
					'id'=>$this->input->post('idbrg'),
					'name'=>$this->input->post('nama'),
					'price'=>$this->input->post('harga'),
					'qty'=>1
				);
			
			$this->cart->insert($insert);
			redirect('cart');
			
		}

		function remove($rowid){
			if($rowid=='all'){
				$this->cart->destroy();
			}
			else{
				$data=array('rowid'=>$rowid,'qty'=>0);
				$this->cart->update($data);
			}

			$data['judul']='Data Transaksi';
			if(!$this->cart->contents()){
				$data['message']='<p>Transkasi Kosong .. !!</p>';
			}
			else{
				$data['message']=$this->session->flashdata('message');
			}

			$this->load->view('header',$data);
			$this->load->view('vcart',$data);
			$this->load->view('footer',$data);
		}

		function update(){
			foreach ($_POST['cart'] as $id => $cart) {
				$price = $cart['price'];
				$amount = $price * $cart['qty'];
				$this->cart->update($cart['rowid'],$cart['qty'],$price,$amount);
			}
			$data['judul']='Data Transaksi';
			if(!$this->cart->contents()){
				$data['message']='<p>Transkasi Kosong .. !!</p>';
			}
			else{
				$data['message']=$this->session->flashdata('message');
			}

			$this->load->view('header',$data);
			$this->load->view('vcart',$data);
			$this->load->view('footer',$data);
		}
	}
?>