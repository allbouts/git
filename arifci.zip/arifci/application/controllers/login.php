<?php

	/**
	* 
	*/
	class login extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			$this->load->helper(array('form','url'));
			$this->load->library('form_validation');
			$this->load->model('login_model');
		}

		function index(){
			$data['judul']='Login';
			$this->load->view('header',$data);
			$this->load->view('v_login',$data);
			$this->load->view('footer',$data);
		}

		function aksi(){
			$this->form_validation->set_rules('uname','User','required');
			$this->form_validation->set_rules('password','Password','required');
			if($this->form_validation->run()){
				$data = array(
					'username'=>$this->input->post('uname'),
					'password'=>md5($this->input->post('password'))
					);
				$cek = $this->login_model->m_aksi($data)->num_rows();
				$dt = $this->login_model->m_aksi($data)->row();
				if($cek > 0){
					$this->session->set_userdata("username",$dt->username);
					$this->session->set_userdata("level",$dt->level);
					redirect('login/sukses');
				}
				else{
					print "Login Gagal! ". anchor('login','Balik');
				}
			}
			else{
				redirect('login');
			}
		}

		function sukses(){
			$dta = $this->session->all_userdata();
			redirect('inventori');
		}

		function logout(){
			$this->session->sess_destroy();
			redirect('login');
		}
	}
?>