<?php
	/**
	* 
	*/
	class simpan extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			$this->load->helper(array('form','url'));
			//$this->load->library('session');
			$this->load->model(array('simpan_model','inv_model'));
		}

		function index(){
			$ceksesi = $this->session->all_userdata();
			if(!isset($ceksesi['idcust'])){
				$data['judul'] = 'Simpan Data Transaksi';
				$data['customer'] = $this->inv_model->getCust();
				$this->load->view('header',$data);
				$this->load->view('customer',$data);
				$this->load->view('footer',$data);
				//print "SESI GAGAL"; //BUAT NGETES DOANG
			}
			else{
				//print "SESI BERHASIL"; //BUAT NGETES DOANG
				redirect('simpan/save');
			}
		}

		function save(){
			$ceksesi = $this->session->all_userdata();
			$gtotal = $ceksesi['gtotal'];
			if(!isset($ceksesi['idcust'])){
				$transH = array(
						'tgl_trans'=>date('Y,m,d'),
						'idcust'=>$ceksesi['idcust'],
						'total'=>$gtotal
					);
			}	
			else{
				$transH = array(
						'tgl_trans'=>date('Y,m,d'),
						'idcust'=>$ceksesi['idcust'],
						'total'=>$gtotal
					);
			}
			//simpan transaksi header
			$id = $this->simpan_model->saveh($transH);
			if($cart = $this->cart->contents()){
				foreach ($cart as $item) {
					$transD = array(
							'notrans'=>$id,
							'idbrg'=>$item['id'],
							'harga'=>$item['price'],
							'qty'=>$item['qty'],
							'jumlah'=>$item['qty'] * $item['price']
						);

					$iddtl = $this->simpan_model->saved($transD);
				}
			}
			print "Data Sudah Disimpan ! <br>";
			$this->cart->destroy();
			session_destroy();
			print anchor('inventori','Kembali');
		}
	}
?>