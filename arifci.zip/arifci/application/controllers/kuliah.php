<?php
	
	/**
	* 
	*/
	class Kuliah extends CI_Controller
	{
		
		private $nama;
		private $matkul;
		private $nilai;
		private $ket;

		function __construct()
		{
			parent::__construct();
			$this->nama = "Eko";
			$this->matkul = "Algoritma";
			$this->nilai = 75;
			$this->ket = "Lulus";
		}



		function setData($nama,$matkul,$nilai){
			$this->nama = $nama;
			$this->matkul = $matkul;
			$this->nilai = $nilai;
			if($this->nilai >= 70){
				$this->ket = "Lulus";
			}
			else{
				$this->ket = "Gagal";
			}
			$this->viewData();
		}

		function viewData(){
			$data['nama'] = $this->nama;
			$data['matkul'] = $this->matkul;
			$data['nilai'] = $this->nilai;
			$data['ket'] = $this->ket;
			$this->load->view('hasil',$data);
		}

	}