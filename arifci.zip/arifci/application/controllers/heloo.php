<?php
	//class ini ditaro di controller
	class Heloo extends CI_Controller{
		
		private $nama;
		private $alamat;
		//function yang selalu menyatu dengan class nya
		function __construct(){
			parent::__construct();
			$this->nama="Arif Herdi Priyatna";
			$this->alamat="Bogor";
		}

		//jika langsung print tidak perlu buat view
		function index(){
			print "This Message From Controller <br>";
			print "Nama :".$this->nama."<br>";
			print "Alamat :".$this->alamat."<br>";
		}


		//mengirim nilai kepada parameter taro di URI
		function setData($nama,$alamat){
			$this->nama=$nama;
			$this->alamat=$alamat;
			//$this->index(); //nyalakan jika ingin ambil nilai via index
			$this->siview();
		}

		//isi function memanggil file tampilan, buat tampilan itu di view
		function siview(){
			$data['nama'] = $this->nama;
			$data['alamat'] = $this->alamat;
			$this->load->view('pesan',$data); //kirim data lewat array // kirim data dari view
		}


		
	}