<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');

	/**
	* 
	*/
	class inventori extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			$this->load->helper(array('url','form'));
			$this->load->model('inv_model');
			$data = $this->session->all_userdata();
			$un = $data['username'];
			if(!isset($un)){
				redirect('login');
			}
			$config['upload_path']='./gambar';
			$config['allowed_types']='gif|jpeg|jpg|png';
			$config['max_size']='2048';
			$config['max_width']='2048';
			$config['max_height']='1768';
			$config['overwrite']=true;
			$this->load->library('upload',$config);
			//$this->load->library(array('pagination','table'));

		}

		function index(){
			$data['judul']="Aplikasi Inventori";
			$this->load->view('header',$data);
			$this->load->view('home');
			$this->load->view('footer');
		}

		function tplpage(){
			$offset = $this->uri->segment(3);
			$limit = 5;
			$jdata = $this->inv_model->getAllData()->num_rows();
			$data['barang'] = $this->inv_model->get_page_list($limit,$offset);
			//membuat pagination nya
			$this->load->library('pagination');
			$config['base_url'] = site_url('inventori/tplpage/');
			$config['total_rows'] = $jdata;
			$config['per_page'] = $limit;
			$config['uri_segment'] = 3;
			$config['full_tag_open'] = '<ul class="pagination">';
			$config['full_tag_close'] = '</ul>';
			$config['first_link'] = false;
			$config['last_link'] = false;
			$config['first_tag_open'] = '<li>';
			$config['first_tag_close'] = '</li>';
			$config['prev_link'] = '&laquo;';
			$config['prev_tag_open'] = '<li>';
			$config['prev_tag_close'] = '</li>';
			$config['next_link'] = '&raquo;';
			$config['next_tag_open'] = '<li>';
			$config['next_tag_close'] = '</li>';
			$config['last_tag_open'] = '<li>';
			$config['last_tag_close'] = '</li>';
			$config['cur_tag_open'] = '<li class="active"><a href="#">';
			$config['cur_tag_close'] = '</a></li>';
			$config['num_tag_open'] = '<li>';
			$config['num_tag_close'] = '</li>';
			$this->pagination->initialize($config);
			$data['pagination'] = $this->pagination->create_links();
			$data['judul'] = "Aplikasi Inventori";
			$this->load->view('header',$data);
			$this->load->view('tplpage',$data);
			$this->load->view('footer');
		}

		function tpldata(){
			//ambil data dari database melalui MODEL
			$data['barang'] = $this->inv_model->getAllData();
			$data['judul']="Aplikasi Inventori";
			$this->load->view('header',$data);
			$this->load->view('frmdtbarang',$data);
			$this->load->view('footer');
		}

		//tampilkan form edit
		function edit(){
			$idbrg = $this->uri->segment(3);
			$data['brg'] = $this->inv_model->getIdBrg($idbrg)->row(); //mendapatkan data barang yang akan dibinding ke form edit
			$data['gol'] = $this->inv_model->getGol(); //mendapatkan data golongan, tujuan nya untuk dibuat combobox di form edit

			//menampilkan datanya (testing)
			//print $data['brg']->idbrg." | ".$data['brg']->nmbrg ;

			//bawa nilai
			$data['judul']="Aplikasi Inventori";
			$this->load->view('header',$data);
			$this->load->view('frmedit',$data);
			$this->load->view('footer');
		}

		//fungsi save data
		function save(){

			//upload gambar
			$message="";
			if(!$this->upload->do_upload()){
				if(isset($_POST['save'])){
					$message=$this->upload->display_errors();
					$lokasi = $this->input->post('gambar');
				}
			}
			else{
				$message="SUKSES !!!";
				$lokasi = base_url().'gambar/'.$this->upload->data('file_name');
			}
			//print $message."<br>".$lokasi;
			//tampung data dari form
			$tbl = $this->input->post('save');
			$idg = $this->input->post('id');
			$idbrg = $this->input->post('idbrg');
			$nmbrg = $this->input->post('nmbrg');
			$idgol = $this->input->post('idgol');
			$hbeli = $this->input->post('hbeli');
			$hjual = $this->input->post('hjual');
			$stok = $this->input->post('stok');
			$satuan = $this->input->post('satuan');

			//tampung data dalam array
			$barang = array(
				'idbrg'=>$idbrg,
				'nmbrg'=>$nmbrg,
				'idgol'=>$idgol,
				'hbeli'=>$hbeli,
				'hjual'=>$hjual,
				'stok'=>$stok,
				'satuan'=>$satuan,
				'gambar'=>$lokasi
			);

			
			

			if($tbl == "Simpan"){
				$id = $this->inv_model->savebrg($barang);
			}
			else{
				$id = $this->inv_model->update($barang,$idg);
			}

			redirect('inventori/tpldata');
		}

		function delete(){
			$idbrg = $this->uri->segment(3);
			$this->inv_model->delbrg($idbrg);
			redirect('inventori/tpldata');
		}

		function addbrg(){
			$data['gol'] = $this->inv_model->getGol();
			$data['judul']="Aplikasi Inventori";
			$this->load->view('header',$data);
			$this->load->view('frmadd',$data);
			$this->load->view('footer');
		}

		function transaksi(){
			$data['judul'] = "Aplikasi Inventori";
			$data['cust'] = $this->inv_model->getCust();
			$data['barang'] = $this->inv_model->getBarang();
			$this->load->view('header',$data);
			$this->load->view('transaksi',$data);
			$this->load->view('footer');
		}

		function getharga(){
			$idbrg=$this->input->post('idbrg');
			$data['harga']=$this->inv_model->getIdBrg($idbrg)->row();
			$this->load->view('vharga',$data);
		}

		function dttransaksi(){
			$data['judul'] = "Aplikasi Inventori";
			$data['transaksi'] = $this->inv_model->dttrans();
			$this->load->view('header',$data);
			$this->load->view('dttransaksi',$data);
			$this->load->view('footer');
		}
	}
?>