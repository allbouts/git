<?php
	
	
	/**
	* 
	*/
	class nilai extends CI_Controller
	{
		
		private $nama;
		private $matkul;
		private $nilai;
		private $ket;

		function __construct()
		{
			parent::__construct();
			$this->load->helper(array('form','url'));
			$this->load->library(array('form_validation'));
			/*
			$this->nama = "Eko";
			$this->matkul = "Algoritma";
			$this->nilai = 75;
			$this->ket = "Lulus";
			*/
		}

		function index(){
			print anchor('nilai/inputData','Inputdata');
			print "<br>";
			print anchor('nilai/viewData','Tampildata');
		}

		function inputData(){
			$data['judul'] = "INPUT DATA MAHASISWA";
			$data['nama'] = "";
			$data['matkul'] = "";
			$data['nilai'] = "";
			$data['ket'] = "";
			$this->load->view('frm_nilai',$data);
		}

		function setData($nama,$matkul,$nilai){
			$this->nama = $nama;
			$this->matkul = $matkul;
			$this->nilai = $nilai;
			if($this->nilai >= 70){
				$this->ket = "Lulus";
			}
			else{
				$this->ket = "Gagal";
			}
			$this->viewData();
		}

		function viewData(){
			$data['judul'] = "INPUT DATA MAHASISWA";
			$data['nama'] = $this->nama;
			$data['matkul'] = $this->matkul;
			$data['nilai'] = $this->nilai;
			$data['ket'] = $this->ket;
			$this->load->view('frm_nilai',$data);
		}

		function proses(){
			$this->form_validation->set_rules('mhs','Mahasiswa','required|alpha');
			$this->form_validation->set_rules('mk','Mata Kuliah','required|alpha');
			$this->form_validation->set_rules('nilai','Nilai','required|numeric');
			//cek apakah ada error ?
			if($this->form_validation->run()){
				$this->nama = $this->input->post('mhs');
				$this->mka = $this->input->post('mk');
				$this->nil = $this->input->post('nilai');
			}
			else{
				$this->nama = "" ;
				$this->mka = "" ;
				$this->nil = 0 ;
			}
			$this->setData($this->nama,$this->mka,$this->nil);


		}

	}