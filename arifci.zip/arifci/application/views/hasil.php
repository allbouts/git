<!DOCTYPE html>
<html>
<head>
	<title>Hasil</title>
</head>
<body>
<center>
	<h3>DATA NILAI MAHASISWA</h3>
</center>
<hr>
<table>
	<tr>
		<td>Nama</td>
		<td>: <?php print $nama?></td>
	</tr>
	<tr>
		<td>Mata Kuliah</td>
		<td>: <?php print $matkul?></td>
	</tr>
	<tr>
		<td>Nilai</td>
		<td>: <?php print $nilai?></td>
	</tr>
	<tr>
		<td>Keterangna</td>
		<td>: <?php print $ket?></td>
	</tr>
</table>
</body>
</html>