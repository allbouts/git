<table class="table table-striped table-bordered">
			<tr>
				<td>Nama Barang</td>
				<td><?php print form_input('nama',$harga->nmbrg,'readonly') ?></td>
			</tr>
			<tr>
				<td>Harga</td>
				<td><?php print form_input('harga',$harga->hjual,'readonly') ?></td>
			</tr>
			<tr>
				<td>Satuan</td>
				<td><?php print $harga->satuan ?></td>
			</tr>
			<tr>
				<td>Stok</td>
				<td><?php print $harga->stok ?></td>
			</tr>
			<tr>
				<td>Gambar</td>
				<td><img src="<?php print $harga->gambar ?>" height="50" width="50" ></td>
			</tr>
</table>