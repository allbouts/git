<hr>
<center><h4>Data Transaksi</h4></center>
<hr>
<div class="container">
	<div class="table-responsive">
		<table border="1" align="center" class="table table-striped table-bordered" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th>No Trans</th>
					<th>Tanggal</th>
					<th>Customer</th>
					<th>Id Barang</th>
					<th>Produk</th>
					<th>Harga</th>
					<th>Qty</th>
				</tr>
			</thead>
			<tbody>
				<?php
					foreach ($transaksi->result() as $dta) { ?>
						<tr>
							<td><?php print $dta->notrans; ?></td>
							<td><?php print $dta->tgl_trans; ?></td>
							<td><?php print $dta->nmcust; ?></td>
							<td><?php print $dta->idbrg; ?></td>
							<td><?php print $dta->nmbrg; ?></td>
							<td><?php print $dta->harga; ?></td>
							<td><?php print $dta->qty; ?></td>
						</tr>
					<?php }
				?>
			</tbody>
		</table>
	</div>
</div>