<hr>
<center><h4>AllRight Reserved untuksemuanya.com</h4></center>
<hr>
</body>
</html>