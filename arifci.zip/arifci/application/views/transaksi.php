<div class="row">
	<div class="container">
		<?php print form_open('cart/add','id="frmtrans"') ?>
		<center><h3>Form Transaksi</h3></center>
		<div class="form-group">
			<label for="notrans">No Transaksi</label>
			<?php print form_input('notrans','',array('class'=>'form-control','id'=>'notrans','readonly'=>'readonly')) ?>
		</div>
		<div class="form-group">
			<label for="idcust">Customer</label>
			<?php print form_dropdown('idcust',$cust,'',array('class'=>'form-control','id'=>'idcust')) ?>
		</div>
		<div class="form-group">
			<label for="idbrg">ID Barang</label>
			<?php print form_input('idbrg','',array('class'=>'form-control','id'=>'idbrg')) ?>
		</div>
		<div id="kotak">
			<table class="table table-striped table-bordered">
				<tr><td>Nama Barang</td><td>...</td></tr>
				<tr><td>Harga</td><td>...</td></tr>
				<tr><td>Satuan</td><td>...</td></tr>
				<tr><td>Stok</td><td>...</td></tr>
				<tr><td>Gambar</td><td>...</td></tr>
			</table>
		</div>
		<?php
			print form_button(array('id'=>'save'),'Simpan');
			print form_close();
		?>
	</div>
</div>
<div class="row">
	<div class="container">
		<div id="detil">
			
		</div>
	</div>
</div>



<script type="text/javascript">
	$("#idbrg").change(function(){
		
			var dt={idbrg:$("#idbrg").val()};
			$.ajax({
				type : "POST",
				url : "<?php print site_url('inventori/getharga'); ?>",
				data : dt,
				success : function(msg){
					$("#kotak").html(msg);
				}
			});
		
	});

	$("#save").click(function(){
		
			var dt=$("#frmtrans").serialize();
			$.ajax({
				type : "POST",
				url : "<?php print site_url('cart/add'); ?>",
				data : dt,
				success : function(msg){
					$("#detil").html(msg);
					//alert('Test');
				}
			});
		
	});
</script>