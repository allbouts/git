<script>
	function kosong(){
		var result=confirm('Anda yakin ?');
		if(result){
			window.location = "<?php print site_url();?>/cart/remove/all"
		}
		else{
			return false;
		}
	}
</script>
<div style="margin:auto;width: 600px">
	<div style="padding-bottom: 10px">
		<h1 align="center">Data Transaksi</h1>
	</div>
<div id="detil">
	<div style="color: #f00">
		<?php print $message ?>
	</div>
	<table class="table table-striped table-bordered">
		<?php if($cart=$this->cart->contents()){ ?>
				<thead>
					<tr>
						<td>No</td>
						<td>Id Barang</td>
						<td>Harga</td>
						<td>Qty</td>
						<td>Jumlah</td>
						<td>Opsi</td>
					</tr>
				</thead>
		<?php
				print form_open('cart/update','id="frmtrans"');
				$gtotal = 0;
				$i = 1;
				foreach ($cart as $item) {
					print form_hidden('cart['.$item['id'].'][id]',$item['id']);
					print form_hidden('cart['.$item['id'].'][rowid]',$item['rowid']);
					print form_hidden('cart['.$item['id'].'][name]',$item['name']);
					print form_hidden('cart['.$item['id'].'][price]',$item['price']);
					print form_hidden('cart['.$item['id'].'][qty]',$item['qty']);
					?>
					<tr>
						<td><?php print $i++;?></td>
						<td><?php print $item['id'];?></td>
						<td><?php print $item['name'];?></td>
						<td><?php print number_format($item['price']);?></td>
						<td><?php print form_input('cart['.$item['id'].'][qty]',$item['qty'],'maxlength="3" size="2" style="text-align: right"'); ?></td>
						<?php 
							$gtotal+=$item['subtotal'];
							$this->session->set_userdata('gtotal',$gtotal);
						?>
						<td>Rp <?php print number_format($item['subtotal']) ?></td>
						<td><?php print anchor('cart/remove/'.$item['rowid'],'hapus') ?></td>
					</tr>
				<?php } ?>
				<tr>
					<td colspan="4">Total : Rp <?php print number_format($gtotal); ?></td>
					<td colspan="3">
						<input type="button" value="Clear" onclick="kosong()">
						<?php print form_button('update','Update',array('id'=>'update'));
						?>
						<input type="button" value="Simpan Transaksi" onclick="window.location='<?php print site_url() ?>/simpan'">
					</td>
				</tr>
		 	<?php } 
		?>
	</table>
</div>
</div>
<script>
	$("#update").click(function(){
		
			var dt=$("#frmtrans").serialize();
			$.ajax({
				type : "POST",
				url : "<?php print site_url('cart/update'); ?>",
				data : dt,
				success : function(msg){
					$("#detil").html(msg);
					//alert('Test');
				}
			});
		
	});
</script>