<!DOCTYPE html>
<html>
<head>
	<title><?php print $judul?></title>
</head>
<body>
<center>
	<h3><?php print $judul?></h3>
</center>
<hr>

	

<?php 
	print validation_errors();
	print form_open('nilai/proses');

?><br>
<table align="center">
<tr>
	<td>Nama</td>
	<td><?php print form_input('mhs',$nama);?></td>
</tr>
<tr>
	<td>Mata Kuliah</td>
	<td><?php print form_input('mk',$matkul);?></td>
</tr>
<tr>
	<td>Nilai</td>
	<td><?php print form_input('nilai',$nilai);?></td>
</tr>
<tr>
	<td></td>
	<td><?php print form_submit('proses','Proses');?></td>
</tr>
<tr>
	<td>Keterangan</td>
	<td><?php print form_input('ket',$ket);?></td>
</tr>
</table>
<?php print form_close();?>
</body>
</html>