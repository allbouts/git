<hr>
<center><h4>Data Barang</h4></center>
<hr>
<center>
<?php
	print form_open('inventori/addbrg');
	print form_submit('tambah','Tambah');
	print form_close();
?>
</center>
<div class="row">
	<div class="col-md-12 text-center">
		<?php print $pagination; ?>
	</div>
</div>
<div class="container">
<div class="table-responsive">
<table border="1" align="center" class="table table-striped table-bordered" cellspacing="0" width="100%">
<thead>
	<tr>
		<th>No</th>
		<th>Kode Barang</th>
		<th>Nama Barang</th>
		<th>Golongan</th>
		<th>Harga Beli</th>
		<th>Harga Jual</th>
		<th>Stok</th>
		<th>Satuan</th>
		<th>Foto</th>
		<?php 
			$dta = $this->session->all_userdata();
			if($dta['level']=='admin'){
		?>
				<th>Action</th>
		<?php } ?>
	</tr>
</thead>
<tbody>
	<?php
		$no = 0;
		foreach ($barang->result() as $br) { ?>
			<tr>
				<td><?php print ++$no;?></td>
				<td><?php print $br->idbrg;?></td>
				<td><?php print $br->nmbrg;?></td>
				<td><?php print $br->idgol;?></td>
				<td><?php print $br->hbeli;?></td>
				<td><?php print $br->hjual;?></td>
				<td><?php print $br->stok;?></td>
				<td><?php print $br->satuan;?></td>
				<td><img src="<?php print $br->gambar;?>" width="50" height="50"></td>
			<?php 
				$dta = $this->session->all_userdata();
				if($dta['level']=='admin'){
			?>
				<td><?php print anchor('inventori/edit/'.$br->idbrg,' Edit','class="glyphicon glyphicon-pencil"') ?> | 
				<?php print anchor('inventori/delete/'.$br->idbrg,' Hapus',array('onclick'=>"return confirm('Yakin ?')", 'class'=>"glyphicon glyphicon-trash")); 
				} ?>
					
				</td>
			</tr>
		<?php }
	?>
</tbody>
</table>
</div>
</div>
<div class="row">
	<div class="col-md-12 text-center">
		<?php print $pagination; ?>
	</div>
</div>
<center>
<?php
	print form_open('inventori/addbrg');
	print form_submit('tambah',' Tambah');
	print form_close();
	
?>
</center>
