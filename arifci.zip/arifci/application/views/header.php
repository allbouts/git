<!DOCTYPE html>
<html>
<head>
	<title><?php print $judul; ?></title>
	<!-- ambil bootstrap -->
	<link href="<?php print base_url()?>assets/css/bootstrap.css" rel="stylesheet">
	<link href="<?php print base_url()?>assets/css/bootstrap.min.css" rel="stylesheet">

	<!-- Jquery -->
	<!--<script src="<?php //print base_url()?>assets/js/jquery.min.js"></script> -->
	<script src="<?php print base_url()?>assets/js/jquery-1.8.3.min.js"></script>
</head>


<body id="dt_example">
<header>
	
</header>
<center><h3><?php print $judul; ?></h3></center>
<div class="container">
<?php 
	$data = $this->session->all_userdata();
	//$usn = $data['username'];
	if(isset($data['username'])){
?>
	<div class="row">
		<ul class="nav nav-tabs">
			<li class="active"><?php print anchor('',' Home','class="glyphicon glyphicon-home"') ?></li>
			<li><?php print anchor('','Master Data') ?></li>
			<li><?php print anchor('inventori/tplpage','Browse Data') ?></li>
			<li><?php print anchor('inventori/transaksi','Transaksi') ?></li>
			<li><?php print anchor('inventori/dttransaksi','Data Transaksi') ?></li>
			<li><?php print anchor('login/logout','Logout') ?></li>
		</ul>
	</div>
<?php } ?>
</div>

</header>

