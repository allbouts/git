<!DOCTYPE html>
<html>
<head>
	<title><?php print $judul ?></title>
</head>
<body>
<?php
	//$brg->result() as $br;
?>
<hr>
<center><h4>Edit Barang</h4></center>
<hr>
<center>
<?php print form_open_multipart('inventori/save'); ?>
	<table>
		<tr>
			<td>Kode Barang</td>
			<td><?php print form_input('idbrg',$brg->idbrg); print form_hidden('id',$brg->idbrg) // dihidden supaya ga bisa diedit ?></td>
		</tr>
		<tr>
			<td>Nama Barang</td>
			<td><?php print form_input('nmbrg',$brg->nmbrg) ?></td>
		</tr>
		<tr>
			<td>Golongan</td>
			<td><?php print form_dropdown('idgol',$gol,$brg->idgol) ?></td>
		</tr>
		<tr>
			<td>Harga Beli</td>
			<td><?php print form_input('hbeli',number_format($brg->hbeli)) ?></td>
		</tr>
		<tr>
			<td>Harga Jual</td>
			<td><?php print form_input('hjual',number_format($brg->hjual)) ?></td>
		</tr>
		<tr>
			<td>Stok</td>
			<td><?php print form_input('stok',number_format($brg->stok)) ?></td>
		</tr>
		<tr>
			<td>Satuan</td>
			<td><?php print form_input('satuan',$brg->satuan) ?></td>
		</tr>
		<tr>
			<td>Gambar</td>
			<td><?php print form_upload('userfile') ?>
				<img src="<?php print $brg->gambar ?>" height="50" width="50">
				<?php print form_hidden('gambar',$brg->gambar)?></td>
		</tr>
		<tr>
			<td></td>
			<td><?php print form_submit('save','Update'); print form_submit('batal', 'Batal')?></td>
		</tr>
	</table>
<?php print form_close(); ?>
</center>
<hr>
<center><?php print anchor('inventori','Back to Home') ?></center>
</body>
</html>