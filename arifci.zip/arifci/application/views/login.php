<?php //session_start() ?>
<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
	<meta charset="utf-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

<title>Sistem Informasi Akademik</title>

<!-- Bootstrap -->

<link href="css/bootstrap.min.css" rel="stylesheet">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->

<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->

<!--[if lt IE 9]>

<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>

<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

<![endif]-->
<style media="screen" type="text/css"> 
html,
body {
   margin:0;
   padding:0;
   height:100%;
}
#container {
   min-height:100%;
   position:relative;
   padding-bottom: 60px;
}
#header {
   background:#ff0;
   padding:10px;
}
#body {
   padding:10px;
   padding-bottom:60px;   /* Height of the footer */
}
#footer {
   position:absolute;
   bottom:0;
   width:100%;
   height:60px;   /* Height of the footer */
   background:gray;
}
</style>

<link href="style.css" rel="stylesheet" type="text/css">

<script src="assets/js/jquery.js"></script>
<script src="assets/js/jquery.min.js"></script>
</head>
<body><center>
<div class="container" style="margin-top: 5%;">
    <div class="col-md-4 col-md-offset-4">
        <div class="panel panel-primary">
            <div class="panel-heading">WELCOME</div>
            <div class="panel-body">



	<form role="form" id=login action="ceklogin.php" method="POST">
		
			<div class="row">
                    <div class="form-group col-xs-12">
                    <label for="username"><span class="text-danger" style="margin-right:5px;">*</span>Username:</label>
                        <div class="input-group">
                            <input class="form-control" id="uname" type="text" name="uname" placeholder="Username" required/>
                            <span class="input-group-btn">
                                <label class="btn btn-primary"><span class="glyphicon glyphicon-user" aria-hidden="true"></label>
                            </span>
                            </span>
                        </div>
                    </div>
                </div>
				
			<div class="row">
                    <div class="form-group col-xs-12">
                        <label for="password"><span class="text-danger" style="margin-right:5px;">*</span>Password:</label>
                        <div class="input-group">
                            <input class="form-control" id="pswd" type="password" name="pswd" placeholder="Password" required/>
                            <span class="input-group-btn">
                                <label class="btn btn-primary"><span class="glyphicon glyphicon-lock" aria-hidden="true"></label>
                            </span>
                            </span>
                        </div>
                    </div>
                </div>
			
				<div class="row">
                    <div class="form-group col-xs-4">
                        <button class="btn btn-primary" id="masuk" type="submit">Login</button>
                    </div>
                </div>
			
		
	</form>
	<?php
		if(isset($_SESSION['error'])){
			$salah=$_SESSION['error'];
			print $salah;
		}
	?>
</div>
</div>
</div>
</div>
</center>
</body>
</html>
<script>
	/*
	$("#masuk").click(function(){
		var info=$("#login").serialize();
		$.ajax({
			type:"POST",
			url:"ceklogin.php",
			data:info,
			success: function(msg){
				window.location("index.php");

			}
		});
	}); */
</script>