<center>
	<h2><?php print $judul ?></h2>	
</center>
<hr>
<?php
	print form_open('login/aksi');
?>
<table align="center">
	<tr>
		<td>Username</td>
		<td><?php print form_input('uname') ?></td>
	</tr>
	<tr>
		<td>Password</td>
		<td><?php print form_input('password') ?></td>
	</tr>
	<tr>
		<td colspan="2" align="center"><?php print form_submit('login','Login') ?></td>
	</tr>
</table>