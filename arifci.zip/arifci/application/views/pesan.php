<!DOCTYPE html>
<html>
<head>
	<title>This Message is fom view</title>
</head>
<body>
<center>
	<h3>This Message is from view</h3>
</center>
<hr>
Nama : <?php print $nama;?><br>
Alamat : <?php print $alamat;?>
</body>
</html>