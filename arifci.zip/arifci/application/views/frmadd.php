<!DOCTYPE html>
<html>
<head>
	<title><?php print $judul ?></title>
</head>
<body>
<?php
	//$brg->result() as $br;
?>
<hr>
<center><h4>Tambah Barang</h4></center>
<hr>
<center>
<?php print form_open_multipart('inventori/save'); ?>
	<table>
		<tr>
			<td>Kode Barang</td>
			<td><?php print form_input('idbrg')?></td>
		</tr>
		<tr>
			<td>Nama Barang</td>
			<td><?php print form_input('nmbrg') ?></td>
		</tr>
		<tr>
			<td>Golongan</td>
			<td><?php print form_dropdown('idgol',$gol) ?></td>
		</tr>
		<tr>
			<td>Harga Beli</td>
			<td><?php print form_input('hbeli') ?></td>
		</tr>
		<tr>
			<td>Harga Jual</td>
			<td><?php print form_input('hjual') ?></td>
		</tr>
		<tr>
			<td>Stok</td>
			<td><?php print form_input('stok') ?></td>
		</tr>
		<tr>
			<td>Satuan</td>
			<td><?php print form_input('satuan') ?></td>
		</tr>
		<tr>
			<td>Gambar</td>
			<td><?php print form_upload('userfile') ?></td>
		</tr>
		<tr>
			<td></td>
			<td><?php print form_submit('save','Simpan'); print form_submit('batal', 'Batal')?></td>
		</tr>
	</table>
<?php print form_close(); ?>
</center>
<hr>
<center><?php print anchor('inventori','Back to Home') ?></center>
</body>
</html>