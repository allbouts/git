-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2018 at 06:20 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventori`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `idbrg` varchar(5) NOT NULL,
  `nmbrg` varchar(30) DEFAULT NULL,
  `idgol` varchar(5) DEFAULT NULL,
  `hbeli` double DEFAULT NULL,
  `hjual` double DEFAULT NULL,
  `stok` int(11) DEFAULT NULL,
  `satuan` varchar(15) DEFAULT NULL,
  `gambar` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`idbrg`, `nmbrg`, `idgol`, `hbeli`, `hjual`, `stok`, `satuan`, `gambar`) VALUES
('b01', 'hardisk', 'g01', 500, 600, 11, 'pcs', 'http://localhost/arifci/gambar/main-thumb-242078430-200-fpkdzutarkptmhykexnztqkkvixmmifz.jpeg'),
('b02', 'mouse', 'g01', 15, 30, 90, 'pcs', 'http://localhost/arifci/gambar/Jessica_Cox_Speaker.jpg'),
('b03', 'Windows 10', 'g02', 300, 400, 16, 'pcs', 'http://localhost/arifci/gambar/598645366.jpg'),
('b04', 'asdd', 'g02', 123, 345543, 123, '123', 'http://localhost/arifci/gambar/wallpaper.jpg'),
('b05', 'sedotan', 'g01', 100, 500, 4, 'pack', 'http://localhost/arifci/gambar/b8cf84e92853318fa61ca6bea957a8ce.jpg'),
('g04', 'Adobe Master Collection', 'g02', 130, 1, 10, 'pcs', 'http://localhost/arifci/gambar/main-thumb-242078430-200-fpkdzutarkptmhykexnztqkkvixmmifz.jpeg'),
('g05', 'Corel Draw', 'g02', 800, 900, 10, 'pcs', 'http://localhost/arifci/gambar/b8cf84e92853318fa61ca6bea957a8ce.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `idcust` varchar(5) NOT NULL,
  `nmcust` varchar(50) DEFAULT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `telp` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`idcust`, `nmcust`, `alamat`, `telp`) VALUES
('c001', 'PT. Indofood', 'Ciawi', '02510929390'),
('c002', 'PT. Adhiwira Elektrikatama', 'Deltamas', '021920392938'),
('c003', 'PT. Uni Makmur Elektrika', 'Cibinong', '02193838490');

-- --------------------------------------------------------

--
-- Table structure for table `golongan`
--

CREATE TABLE `golongan` (
  `idgol` varchar(5) NOT NULL,
  `golongan` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `golongan`
--

INSERT INTO `golongan` (`idgol`, `golongan`) VALUES
('g01', 'hardware'),
('g02', 'software');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(15) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `level` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `level`) VALUES
('admin', 'e10adc3949ba59abbe56e057f20f883e', 'admin'),
('user', 'c33367701511b4f6020ec61ded352059', 'user'),
('admin', '21232f297a57a5a743894a0e4a801fc3', 'admin'),
('user', 'ee11cbb19052e40b07aac0ca060c23ee', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `notrans` int(10) NOT NULL,
  `tgl_trans` date DEFAULT NULL,
  `idcust` varchar(5) DEFAULT NULL,
  `total` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`notrans`, `tgl_trans`, `idcust`, `total`) VALUES
(1, '2017-05-30', 'c001', NULL),
(2, '2017-05-30', 'c001', NULL),
(3, '2017-05-30', 'c003', NULL),
(4, '2017-05-30', 'c001', 30),
(5, '2017-05-30', 'c002', 600),
(6, '2017-06-06', 'c002', 600),
(7, '2017-06-06', 'c002', 346043),
(8, '2017-06-07', 'c001', 630),
(9, '2017-06-10', 'c002', 600),
(10, '2017-06-23', 'c001', 600);

-- --------------------------------------------------------

--
-- Table structure for table `transd`
--

CREATE TABLE `transd` (
  `notrans` varchar(10) DEFAULT NULL,
  `idbrg` varchar(5) DEFAULT NULL,
  `harga` double DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `jumlah` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transd`
--

INSERT INTO `transd` (`notrans`, `idbrg`, `harga`, `qty`, `jumlah`) VALUES
('2', 'b02', 30, 1, 30),
('3', 'b01', 600, 1, 600),
('4', 'b02', 30, 1, 30),
('5', 'b01', 600, 1, 600),
('6', 'b01', 600, 1, 600),
('7', 'b04', 345543, 1, 345543),
('7', 'b05', 500, 1, 500),
('8', 'b01', 600, 1, 600),
('8', 'b02', 30, 1, 30),
('9', 'b01', 600, 1, 600),
('10', 'b01', 600, 1, 600);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`idbrg`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`idcust`);

--
-- Indexes for table `golongan`
--
ALTER TABLE `golongan`
  ADD PRIMARY KEY (`idgol`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`notrans`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `notrans` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
