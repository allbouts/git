-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 12 Apr 2018 pada 11.35
-- Versi Server: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tiketdb`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `cekout`
--

CREATE TABLE `cekout` (
  `name` varchar(22) NOT NULL,
  `email` varchar(50) NOT NULL,
  `id` int(3) NOT NULL,
  `qty` smallint(6) NOT NULL,
  `price` float NOT NULL,
  `cek` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `event`
--

CREATE TABLE `event` (
  `ID` int(3) NOT NULL,
  `Event` varchar(100) NOT NULL,
  `DateTime` datetime NOT NULL,
  `Location` varchar(100) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `Payment` varchar(20) NOT NULL,
  `Price` double NOT NULL,
  `Quota` int(11) NOT NULL,
  `Pic` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `event`
--

INSERT INTO `event` (`ID`, `Event`, `DateTime`, `Location`, `Type`, `Payment`, `Price`, `Quota`, `Pic`) VALUES
(2, 'How To Create A Sustainable Bussiness', '2018-03-20 00:00:00', 'Avenue 8', 'Business', 'Paid', 120000, 100, '2.jpg'),
(3, 'Programmer Jaman Now - Get Hired by Unicorn Tech', '2018-05-21 00:00:00', 'Astekindo Jakarta', 'Business', 'Paid', 23000, 20, '003.png'),
(4, 'MozBelajar: Syncing Product Design ', '2018-03-27 00:00:00', 'Mozilla Community Space', 'Business', 'Free', 0, 25, '004.jpg'),
(10, 'Apa aja', '2017-03-21 00:00:00', 'Avenue 8', 'Business', 'Paid', 10000, 20, '10.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
