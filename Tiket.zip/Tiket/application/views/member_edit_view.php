<?php
defined('BASEPATH') OR exit ('Jangan Masuk Tanpa Izin');
?>
<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
	<?php print anchor('member/tampil','Lihat data');?>
	<h2>Edit Event</h2>
	<?php
		print form_open('member/update'); //sama dengan <form action='xx'>
		print form_input ('idmember',$member[0]['idmember'],'placeholder="IDMember"');
		print br();
		print form_input('email',$member[0]['email'],'placeholder="email"');
		print br();
		print form_input('password',$member[0]['password'],'placeholder="password"');
		print br();
		print form_submit('submit','Perbarui');
		print br();	
		print form_reset('reset','Ulangi');
		print form_close();
		?>
		<p><small>{elapsed_time}detik</small></p>
</body>

</html>