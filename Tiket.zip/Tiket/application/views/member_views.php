<?php
defined('BASEPATH') OR Exit('No direct script acces allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
	<?php print anchor('member/tampil','Lihat data');?>
	<h2>Input member</h2>
	<?php
		print form_open('member/simpan'); //sama debgab <form action='xxx'>
		print form_input('idmember', '', 'placeholder="idmember"'); //input type="text" name="xx" placeholder="xx"
		print br();
		print form_input('email', '', 'placeholder="email"');
		print br();
		print form_input('password', '', 'placeholder="password"');
		print br();
		
		print form_submit('submit','Simpan');
		print form_reset('reset','Ulangi');
		print form_close();
	?>
</body>
</html>