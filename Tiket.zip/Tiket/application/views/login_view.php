<?php
defined('BASEPATH') OR exit ('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
	<?php
	print $pesan;
	print form_open('login/in');
	print form_input('username','' , 'placeholder="Username"'); 	
	print br();
	print form_password('password','' , 'placeholder="Password"'); 	 
	print br();
	print form_submit('submit','LOGIN');
	print form_reset('reset','Ulangi');
	print form_close();
	?>
</body>
</html>