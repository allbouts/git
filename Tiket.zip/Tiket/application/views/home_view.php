<html>
<head>
<style type="text/css">	
	body{ 
		background-color:#edeff4;
		font-family:"calibri", cambria, optima;
		color:#333333;
	}
	
	.wrap{
		position:relative;
		margin:auto;
		padding:auto;
		width:900px;
		background-color:blue;		
	}
	
	.head{
		width:100%;
		height:300px;		
	}
	
	.box{		
		float:left;
		position:relative;
		background-color:white;		
		width:290;
		height:280;
		margin:30 0 10 10;
	}	
	
	.box .image{
		width:100%;
		height:170;
		overflow:hidden;
	}
	
	.box .waktu{
		font-size:11pt;
	}
	
	.box .judul{
		font-size:12pt;
		font-weight:bold;
	}
	
	.box .tempat{
		font-size:9pt;
	}
	
	.button {			
		position:relative;
		background-color: #4CAF50;
		border: none;
		color: white;
		padding: 15px 32px;
		margin-top:10;
		text-align: center;
		text-decoration: none;
		display: inline-block;
		font-size: 16px;
		width:100%;
		cursor: pointer;
	}
	
	.subhead{
		position:relative;
		text-align:right;
		padding:10 10 0 0;
		height:30;
		background-color:white;		
	}
}	
</style>
</head>
<body>
	<div class="wrap">	
	<div class="head"></div>	
	<div class="subhead"><?php print anchor('home/cart/', 'Keranjang '.$this->cart->total_items()) ?></div>
	<?php foreach($event as $event_item): ?>	
			<div class="box">
				<div class="image">
					<?php 
					if (!empty($event_item['Pic'])){
						print img(array('src'=>'/event_imgs/'.$event_item['Pic'], 'height'=> '180'));
						print br();
					}	
					?>
				</div>
				<div class="waktu"><?php print $event_item['DateTime']; ?></div>
				<div class="judul"><?php print $event_item['Event']; ?></div>
				<div class="tempat">
					<?php 
						print $event_item['Location']; 
						print $event_item['Price']; 
					?>
				</div>
				<button class="button" onclick="location.href='<?php print base_url().'index.php/home/daftar/'. $event_item['ID'] ?>'">DAFTAR</button>	 					
			</div>
	<?php endforeach; ?>		 					
</div>

</body>
</html>