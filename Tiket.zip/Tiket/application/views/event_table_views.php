<?php
defined('BASEPATH') OR Exit('No direct script acces allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<style type="text/css">
	@media print{
		table{
			width="100%";
			border-collapse:collapse;
		}
	}
	</style>
</head>
<body>
	<?php print anchor('home','Daftar Event');?>
	<?php print anchor('tiket/index','Tambah data');?>
	<a href="javascript:window.print()">Cetak</a>
	<h2>Data Event</h2>
	<table border="1">
		<tr>
			<th>Event</th>
			<th>Location</th>
			<th>Payment</th>
			<th>Price</th>
			<th>Quota</th>
			<th>&nbsp;</th>
		</tr>
		<?php foreach($event as $event_item):?>
		<tr>
			<td>
				<?php
				if(!empty($event_item['Pic'])){
					print img(array('src'=>'/event_imgs/'.$event_item['Pic'], 'height'=>'100'));
					print br();
				}
				?>
				<b><?php print $event_item['Event'];?></b></br>
				<?php print $event_item['DateTime'];?>
			</td>
			<td><?php print $event_item['Location'];?></td>
			<td><?php print $event_item['Payment'];?></td>
			<td><?php print $event_item['Price'];?></td>
			<td><?php print $event_item['Quota'];?></td>
			<td>
				<?php print anchor('tiket/edit/'.$event_item['ID'],'Edit');?>
				<?php print anchor('tiket/hapus/'.$event_item['ID'],'Hapus');?>
			</td>
		</tr>
		<?php endforeach;?>
	</table>
</body>
</html>