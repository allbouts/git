<?php
defined('BASEPATH') OR exit ('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
	<?php print anchor('event/tampil', 'Lihat data');?>			
	<h2>Edit Event</h2>
	<?php
	print form_open_multipart('event/update'); //<------------------
	
	//hidden
	print form_hidden('tempid', $event[0]['ID']); //<------------------
	print form_hidden('temppic', $event[0]['Pic']); //<------------------
	//-----------------
	
	print form_input('id', $event[0]['ID'], 'placeholder="ID"'); 
	print br(); //<br>
	print form_input('event', $event[0]['Event'], 'placeholder="Event" readonly');
	print br();
	print form_input('datetime', $event[0]['DateTime'], 'placeholder="Date Time"');
	print br();
	print form_input('location', $event[0]['Location'], 'placeholder="Location"');
	print br();
	
	$option = array(
				'Business' => 'Business',
				'Concert' => 'Concert',
				'Education' => 'Education',
				'Foodies' => 'Foodies',
				'Party' => 'Party',
				'Tour' => 'Tour',
				'Sports' => 'Sports',
				'Charity' => 'Charity'
			  );				  
	print form_dropdown('type', $option, $event[0]['Type']);
	print br();
	
	$option = array(
				'Free' => 'Free',
				'Paid' => 'Paid'
			  );				  
	print form_dropdown('payment', $option, $event[0]['Payment']);
	print br();		
	print form_input('price', $event[0]['Price'], 'placeholder="Price"');
	print br();	
	print form_input('quota', $event[0]['Quota'], 'placeholder="Quota"');
	print br();	
	
	//image -----------------------------------
	if (!empty($event[0]['Pic'])){
		print img(array('src'=>'/event_imgs/'.$event[0]['Pic'], 'height'=> '100'));
		print br();	
		print anchor('event/hapus_gambar/'.$event[0]['ID'].'/'.$event[0]['Pic'], 'Hapus');
		print br();	
	}
	//----------------------------------------
	print form_upload('pic','');
	print br();	
	print form_submit('submit','Perbarui');
	print form_reset('reset','Ulangi');
	print form_close();
	?>				
	<p><small>{elapsed_time} detik</small></p>
</body>
</html>