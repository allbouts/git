<?php 
defined('BASEPATH') OR Exit ('Jangan Masuk');
?>
<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
	<h2>Data Member</h2>
	<?php print anchor('member/index','Tambah data');?>
	<table border="1">
		<tr>
		<th>ID Member</th>
		<th>Email</th>
		<th>Password</th>
		<th>&nbsp;</th>
		</tr>
		<?php foreach ($member as $member_item):?>
		<tr>
			<td>
				<?php print $member_item['idmember'];?>
			</td>
			<td><?php print $member_item['email'];?></td>
			<td><?php print $member_item['password'];?></td>
			<td><?php print anchor('member/edit/'.$member_item['idmember'],'Edit');?></td>
			<td><?php print anchor('member/hapus/'.$member_item['idmember'],'Hapus');?></td>
		</tr>
		<?php endforeach;?>
	</table>
</body>
</html>