<?php
defined('BASEPATH') OR exit ('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
	<h2>Invoice</h2>
	<table border="1" width="400">
	<tr>
		<td>Name</td><td>Qty</td><td>Harga</td><td>Jumlah</td>
	</tr>
	<?php
	print "Nama: ". $this->session->userdata('name'); 
	print br();
	print "Email: ". $this->session->userdata('email'); 

	foreach ($this->cart->contents() as $items){
	?> 
	<tr>
		<td><?php print $items['name']; ?></td>
		<!-- BUANG $i. -->
        <td><?php print $items['qty']; ?></td>
		<td style="text-align:right">Rp.<?php print $items['price']; ?></td>
		<td style="text-align:right">Rp.<?php print $items['subtotal']; ?></td>
	</tr>
	<?php } ?>
	<tr>
		<td colspan="3"></td>
		<td style="text-align:right">Rp.<?php print $this->cart->total(); ?></td>
	</tr>
	</table>
	<a href="javascript:window.print();">Print</a>
</body>
</html>