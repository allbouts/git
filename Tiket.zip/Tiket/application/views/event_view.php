<?php
defined('BASEPATH') OR exit ('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
	<?php print anchor('event/tampil', 'Lihat data');?>			
	<h2>Input Event</h2>
	<?php
	print form_open_multipart('event/simpan'); //<form action='xxx'>
	print form_input('id', '', 'placeholder="ID"'); //<input type="text" name="xx" value="" placeholder="xx">		
	print br(); //<br>
	print form_input('event', '', 'placeholder="Event"');
	print br();
	print form_input('datetime', '', 'placeholder="Date Time"');
	print br();
	print form_input('location', '', 'placeholder="Location"');
	print br();
	
	$option = array(
				'Business' => 'Business',
				'Concert' => 'Concert',
				'Education' => 'Education',
				'Foodies' => 'Foodies',
				'Party' => 'Party',
				'Tour' => 'Tour',
				'Sports' => 'Sports',
				'Charity' => 'Charity'
			  );				  
	print form_dropdown('type', $option);
	print br();
	
	$option = array(
				'Free' => 'Free',
				'Paid' => 'Paid'
			  );				  
	print form_dropdown('payment', $option);
	print br();	
	print form_input('price', '', 'placeholder = "Price"');
	print br();	
	print form_input('quota','', 'placeholder="Quota"');
	print br();	
	print form_upload('pic','');
	print br();	
	print form_submit('submit','Simpan');
	print form_reset('reset','Ulangi');
	print form_close();
	?>				
</body>
</html>