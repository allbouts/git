<html>
<head></head>
<body>
<?php  
print anchor('home/index', 'Halaman utama'); 
?>
<table cellpadding="6" cellspacing="1" style="width:50%" border="1">
<tr>
	<th>Event</th>        
	<th>Qty</th>
	<th style="text-align:right">Harga</th>
	<th style="text-align:right">Jumlah</th>
	<th>&nbsp;</th>
</tr>
<?php 
$i = 1; 
foreach ($this->cart->contents() as $items): ?>
	<?php 
	print form_open('home/update');  //<-------------------
	print form_hidden('rowid', $items['rowid']);  
	?>
    <tr>
		<td><?php print $items['name']; ?></td>
		<!-- BUANG $i. -->
        <td><?php print form_input(array('name' =>'qty', 'value' => $items['qty'])); ?></td>
		<td style="text-align:right"><?php print $items['price']; ?></td>
		<td style="text-align:right">Rp.<?php print $items['subtotal']; ?></td>
		<td>
			<?php 
			print form_submit('submit', 'Update'); //<-----------------------
			print anchor('home/hapus/'.$items['rowid'], 'Hapus') ;
			print form_close(); //<-----------------------------
			?>
		</td>
     </tr>
	<?php $i++; 
endforeach; ?>
<tr>
	<td colspan="2"> </td>
	<td ><strong>Total</strong></td>
	<td style="text-align:right">Rp.<?php print $this->cart->total(); ?></td>
</tr>
</table>
<button class="button" onclick="location.href='<?php print base_url().'index.php/home/bio' ?>'">CEK OUT</button>	
</body>
</html>
