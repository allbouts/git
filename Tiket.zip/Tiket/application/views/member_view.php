<?php 
defined('BASEPATH') OR Exit ('Jangan Masuk');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title></title>
</head>
<body>
<?php print anchor('member/tampil','List Data');?>
	<h2>Input Member</h2>
	<?php 
		print form_open('member/simpan'); //sama dengan <form action='xxxx'>
		print form_input('idmember', '', 'placeholder="idmember"'); //input type="text" name="xxx" value="xxx"
		print br(); //<br>
		print form_input('email', '', 'placeholder="email"');
		print br(); //<br>
		print form_input('password', '', 'placeholder="password"');
		print br(); //<br>
		
		print form_submit('submit', 'Simpan');
		print form_reset('reset', 'Ulangi');
		print form_close();
	 ?>
</body>
</html>