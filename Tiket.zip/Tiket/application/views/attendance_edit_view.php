<?php
defined('BASEPATH') OR exit ('Jangan Masuk Tanpa Izin');
?>
<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
	<?php print anchor('attendance/tampil','Lihat data');?>
	<h2>Edit Event</h2>
	<?php
		print form_open('attendance/update'); //sama dengan <form action='xx'>
		print form_input ('id',$attendance[0]['id'],'placeholder="id"');
		print br();
		print form_input('idmember',$attendance[0]['idmember'],'placeholder="idmember"');
		print br();
		print form_submit('submit','Perbarui');
		print br();	
		print form_reset('reset','Ulangi');
		print form_close();
		?>
		<p><small>{elapsed_time}detik</small></p>
</body>

</html>