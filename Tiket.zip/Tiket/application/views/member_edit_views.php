<?php
defined('BASEPATH') OR Exit('No direct script acces allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
	<?php print anchor('member/tampil','Lihat data');?>
	<h2>Edit Member</h2>
	<?php
		print form_open('member/update'); //sama debgab <form action='xxx'>
		print form_input('idmember', $member[0]['idmember'], 'placeholder="idmember"'); //input type="text" name="xx" placeholder="xx"
		print br();
		print form_input('email', $member[0]['email'], 'placeholder="email"');
		print br();
		print form_input('password', $member[0]['password'], 'placeholder="password"');
		print br();
		print form_submit('submit','Perbarui');
		print form_reset('reset','Ulangi');
		print form_close();
	?>
	<p><small>{elapsed_time}detik</small></p>
</body>
</html>