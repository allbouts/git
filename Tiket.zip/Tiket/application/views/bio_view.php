<?php
defined('BASEPATH') OR exit ('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
	<?php print anchor('home/cart', 'Lihat Keranjang');?>			
	<h2>Input Biodata</h2>
	<?php
	print form_open_multipart('home/bio_simpan'); 
	print form_input('name', '', 'placeholder="Name"');
	print br();
	print form_input('email', '', 'placeholder="Email"');
	print form_submit('submit','Simpan');
	print form_reset('reset','Ulangi');
	print form_close();
	?>				
</body>
</html>