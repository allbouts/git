<?php 
defined('BASEPATH') OR Exit ('Jangan Masuk');
?>
<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
	<h2>Data Attendance</h2>
	<?php print anchor('attendance/index','Tambah data');?>
	<table border="1">
		<tr>
		<th>ID</th>
		<th>ID Member</th>
		<th>&nbsp;</th>
		</tr>
		<?php foreach ($attendance as $attendance_item):?>
		<tr>
			<td>
				<?php print $attendance_item['id'];?>
			</td>
			<td><?php print $attendance_item['idmember'];?></td>
			<td><?php print anchor('attendance/edit/'.$attendance_item['id'],'Edit');?></td>
			<td><?php print anchor('attendance/hapus/'.$attendance_item['id'],'Hapus');?></td>
		</tr>
		<?php endforeach;?>
	</table>
</body>
</html>