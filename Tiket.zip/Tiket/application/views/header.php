<html>
<head>
<style type="text/css">
	* {
        margin: 0;
        padding: 0;       
    }
	
	#head{
		position:relative;
		background-color:red; 
		width:100%; 
		margin-bottom:20px;
		padding:5px;
		text-align:right;
	}
	
	#head a{
		margin-right:20px;
	}
</style>
</head>
<body>
<div id="head">
	<?php 
	print anchor('event/tampil', 'Event');	
	print anchor('event/member', 'Member');
	print anchor('login/out', 'Logout');
	?>		
</div>
</body>
</html>