<?php
defined('BASEPATH') OR Exit('No direct script acces allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
	<?php print anchor('member/index','Tambah data');?>
	<h2>Data Member</h2>
	<table border="1">
	<tr>
	<th>idmember</th>
	<th>email</th>
	<th>aksi</th>
	</tr>
	 <?php foreach($member as $member_item):?>
	<tr>
	<td>
	 <?php print $member_item['idmember'];?>
	</td>
	<td> <?php print $member_item['email'];?></td>
	<td><?php print anchor('member/edit/'.$member_item['idmember'],'Edit');?>
		<?php print anchor('member/hapus/'.$member_item['idmember'],'Hapus');?>
	</td>
	</tr>
	<?php endforeach;?>
</table>
</body>
</html>