<?php 
defined('BASEPATH') OR Exit ('Jangan Masuk');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title></title>
</head>
<body>
<?php print anchor('attendance/tampil','List Data');?>
	<h2>Input Attendance</h2>
	<?php 
		print form_open('attendance/simpan'); //sama dengan <form action='xxxx'>
		print form_input('id', '', 'placeholder="id"'); //input type="text" name="xxx" value="xxx"
		print br(); //<br>
		print form_input('idmember', '', 'placeholder="idmember"');
		print br(); //<br>
		
		print form_submit('submit', 'Simpan');
		print form_reset('reset', 'Ulangi');
		print form_close();
	 ?>
</body>
</html>