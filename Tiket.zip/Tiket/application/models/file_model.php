<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class file_model extends CI_Model
{
	public function __construct()
	{
	}
	
	public function upload_file($file, $loc, $rename)
	{
		$config['upload_path'] = $loc;
		$config['file_name'] = $rename;
		$config['allowed_types'] = 'gif|jpg|png';

		$this->load->library('upload', $config);

		if (!$this->upload->do_upload($file))
		{
			return false; 
		}
		else
		{
			return true;
		}
	}

	public function remove_file($f)
	{
		
	}	
}
?>