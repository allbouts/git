<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class tiket_model extends CI_Model
{
	public function __construct()
	{
		//panggil fungsi-fungsi / helper database
		$this->load->database();
	}
	
	//1.select(table, id)
	public function get_data($table, $id)
	{
		if($id != "") //kalo id-nya ada
		{
			$query = $this->db->get_where($table, $id);
		}
		else
		{
			$query = $this->db->get($table);
		}
		
		return $query->result_array();
	}
	
	//2. insert
	public function set_data($table, $data)
	{
		$this->db->insert($table, $data);
	}
	
	//3. update(table, data, id)
	public function update_data($table, $data, $id)
	{
		$this->db->update($table, $data, $id);	
	}
	
	//4. delete(table, id)
	public function remove_data($table, $id)
	{
		$this->db->delete($table, $id);	
	}
	
	
	public function check(){
		
		return false;
	}
	
}
?>