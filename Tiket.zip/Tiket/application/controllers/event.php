<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class event extends CI_Controller  
{
	public function __construct()
	{
		parent::__construct(); 
		//memanggil library dan helper
		$this->load->helper(array('form', 'html', 'url'));
		$this->load->model('tiket_model');
		$this->load->library('session'); 
		
		//cek session
		if ($this->session->userdata('email') == ''){
			redirect('login/index');
		}	
	}
	
	public function index()
	{
		//memanggil view yang tadi kita buat
		$this->load->view('header');
		$this->load->view('event_view');
	}
	
	public function simpan()
	{	
		$filename = ""; 		
		
		if (empty($_FILES['pic']) || $_FILES['pic']['name'] == ''){ //<-----------------------
			$filename =  ""; //<-----------------------
		}elseif(!empty($_FILES['pic'])) { //<-----------------------			
			$config['upload_path'] = './event_imgs/';
			$config['file_name'] = $this-> input->post('id'); //rename
			$config['allowed_types'] = 'gif|jpg|png';

			$this->load->library('upload', $config);

			if (!$this->upload->do_upload('pic')) {
				die("Error: " .$this->upload->display_errors());						
			}else{				
				$filename = $this->upload->data('file_name'); 
			}
		} 
		
		//urusan harga
		if ($this->input->post('payment') == "Free"){ //<----------------------------
			$price = 0;//<----------------------------
		}else{//<----------------------------
			$price = $this->input->post('price');//<----------------------------
		}//<----------------------------
		
		$data = array(
				'id' => $this->input->post('id'),
				'event' => $this->input->post('event'),
				'datetime' => $this->input->post('datetime'),
				'location' => $this->input->post('location'),
				'type' => $this->input->post('type'),
				'payment' => $this->input->post('payment'),
				'price' => $price, //<----------------------------
				'quota' => $this->input->post('quota'),
				'pic' => $filename 
				);
				
		$this->tiket_model->set_data('event', $data);
		$this->index(); //panggil funct index
	}
	
	public function tampil()
	{			
		$data['event'] = $this->tiket_model->get_data('event', ''); //ambil data		
		
		$this->load->view('header');
		$this->load->view('event_table_view', $data); //tampilkan di view
	}
	
	public function hapus()
	{		
		//hapus gambar jika ada
		if  (!empty($this->uri->segment(4)))
			unlink('./event_imgs/'.$this->uri->segment(4)); 
			
		$this->tiket_model->remove_data('event', array('ID' => $this->uri->segment(3)));
		$this->tampil(); //kembalikan ke tampil data
	}
	
	public function edit()
	{
		$data['event'] = $this->tiket_model->get_data('event', array('ID' => $this->uri->segment(3))); 
		
		$this->load->view('header');
		$this->load->view('event_edit_view', $data); //<----- belum bikin --> save as dari event_view
	}	
	
	public function update()
	{		
		$filename = "";
		
		if (empty($_FILES['pic']) ||  $_FILES['pic']['name'] == ''){
			$filename =  $this->input->post('temppic');//<-----------
		}elseif(!empty($_FILES['pic'])) { //jika ada gambar yang mau diupload
			//hapus gambar lama jika ada
			if  (!empty($this->input->post('temppic')))
				unlink('./event_imgs/'.$this->input->post('temppic')); 
			
			$config['upload_path'] = './event_imgs/';
			$config['file_name'] = $this->input->post('id'); //rename
			$config['allowed_types'] = 'gif|jpg|png';

			$this->load->library('upload', $config);

			if (!$this->upload->do_upload('pic')) {
				die("Error: " .$this->upload->display_errors());						
			}else{
				//mengambil nama file yang sudah diupload
				$filename = $this->upload->data('file_name'); 
			}
		}
		
		//urusan harga
		if ($this->input->post('payment') == "Free"){ //<----------------------------
			$price = 0;//<----------------------------
		}else{//<----------------------------
			$price = $this->input->post('price');//<----------------------------
		}//<----------------------------
		
		$data = array(
				'event' => $this->input->post('event'),
				'datetime' => $this->input->post('datetime'),
				'location' => $this->input->post('location'),
				'type' => $this->input->post('type'),
				'payment' => $this->input->post('payment'),
				'price' => $price, //<--------------------
				'quota' => $this->input->post('quota'),
				'pic' => $filename 
				);
				
		$id = array('id' => $this->input->post('id'));
		$this->tiket_model->update_data('event', $data, $id);
		$this->tampil();
	}
	
	//--------- d a r i  s i n i------------------
	public function hapus_gambar(){
		//unlink (hapus file)
		unlink('./event_imgs/'.$this->uri->segment(4));
		
		//update data
		$data = array('pic' => '');
		$id = array('id' => $this->uri->segment(3));
		$this->tiket_model->update_data('event', $data, $id);
		
		//redirect
		redirect('event/edit/'.$this->uri->segment(3));
	}
	//--------- sampai  s i n i------------------
}
?>