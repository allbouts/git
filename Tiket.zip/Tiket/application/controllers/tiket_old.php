<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class event extends CI_Controller  
{
	public function __construct()
	{
		parent::__construct(); 
		//memanggil library dan helper
		$this->load->helper(array('form', 'html', 'url'));
		$this->load->model('tiket_model');
	}
	
	public function index()
	{
		//memanggil view yang tadi kita buat
		$this->load->view('event_view');
	}
	
	public function simpan()
	{		
		$data = array(
				'id' => $this->input->post('id'),
				'event' => $this->input->post('event'),
				'datetime' => $this->input->post('datetime'),
				'location' => $this->input->post('location'),
				'type' => $this->input->post('type'),
				'payment' => $this->input->post('payment'),
				'quota' => $this->input->post('quota')
				);
		$this->tiket_model->set_data('event', $data);
		$this->index(); //panggil funct index
	}
	
	public function tampil()
	{
		$data['event'] = $this->tiket_model->get_data('event', ''); //ambil data		
		$this->load->view('event_table_view', $data); //tampilkan di view
	}
	
	public function hapus()
	{		
		$this->tiket_model->remove_data('event', array('ID' => $this->uri->segment(3)));
		$this->tampil(); //kembalikan ke tampil data
	}
	
	public function edit()
	{
		$data['event'] = $this->tiket_model->get_data('event', array('ID' => $this->uri->segment(3))); 
		$this->load->view('event_edit_view', $data); //<----- belum bikin --> save as dari event_view
	}	
	
	public function update()
	{
		$data = array(
				'event' => $this->input->post('event'),
				'datetime' => $this->input->post('datetime'),
				'location' => $this->input->post('location'),
				'type' => $this->input->post('type'),
				'payment' => $this->input->post('payment'),
				'quota' => $this->input->post('quota')
				);
		$id = array('id' => $this->input->post('id'));
		$this->tiket_model->update_data('event', $data, $id);
		$this->tampil();
	}
}
?>