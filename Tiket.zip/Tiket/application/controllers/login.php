<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class login extends CI_Controller  
{
	public function __construct()
	{
		parent::__construct(); 
		$this->load->helper(array('form', 'html', 'url'));
		$this->load->model('tiket_model');
		$this->load->library(array('cart', 'session')); 
	}
	
	public function index($p = '')
	{	
		//cek session
		if ($this->session->userdata('email') != ''){
			redirect('event/tampil');
		}
		
		$data['pesan'] = $p;
		$this->load->view('login_view', $data); 		
	}
	
	public function in()
	{	
		$data = array(
					'email'=>$this->input->post('username'),
					'password'=>$this->input->post('password'));
		$res = $this->tiket_model->get_data('member', $data);
				
		//cek jika datanya ada
		if (isset($res[0]['idmember']) &&
			isset($res[0]['email']) &&
			isset($res[0]['password'])){
			
			//masukkan ke session username dan password
			$data = array(
				'email' => $res[0]['email'],
				'password' => $res[0]['password']
			);

			$this->session->set_userdata($data);
			
			//setelah mendaftakan pada session kemudian buka menu
			redirect('event/tampil');
		}else{
			$this->index('Login gagal!');
		}
	}
	
	public function out(){
		$this->session->sess_destroy();
		$this->index();	
	}
}
?>