<?php 
defined('BASEPATH') OR Exit ('Jangan Masuk');

//mengambil fungsi dari CI_Controller
class member extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		//memanggil library dan helper
		$this->load->helper(array('form', 'html', 'url'));
		$this->load->model('tiket_model');
	}

	public function index()
	{
		//memanggil view yang sudah dibuat
		$this->load->view('member_view');
	}
	public function simpan()
	{
		$data = array(
				'idmember' => $this->input->post('idmember'),
				'email' => $this->input->post('email'),
				'password' => $this->input->post('password')
				);

		$this->tiket_model->set_data('member', $data);
		$this->index(); //panggil function index
	}

	public function tampil()
	{
		//1. Ambil Data
		$data['member']=$this->tiket_model->get_data('member', '');
		$this->load->view('member_table_view',$data);//tampilkan di view
	}

	public function hapus()
	{
		$this->tiket_model->remove_data('member', array('idmember'=>$this->uri->segment(3)));
		$this->tampil();//kembalikan ke tampilan data
	}

	public function edit()
	{
		$data['member']=$this->tiket_model->get_data('member',  array('idmember'=>$this->uri->segment(3)));
		$this->load->view('member_edit_view',$data);
	}

	public function update()
	{
		$data = array(
		'email'=>$this->input->post('email'),
		'password'=>$this->input->post('password')
		);
		$id= array('idmember' =>$this->input->post('idmember'));
		$this->tiket_model->update_data('member', $data, $id);
		$this->tampil();
	}
	
	public function tampil1()
	{
		$this->load->view('member_view');
	}
}
 ?>