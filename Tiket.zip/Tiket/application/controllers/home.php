<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class home extends CI_Controller  
{
	public function __construct()
	{
		parent::__construct(); 
		$this->load->helper(array('form', 'html', 'url'));
		$this->load->model('tiket_model');
		$this->load->library(array('cart', 'session')); //<-------------		
	}
	
	public function index()
	{
		$data['event'] = $this->tiket_model->get_data('event', '');
		$this->load->view('home_view', $data); 		
	}
	
	public function daftar()
	{
		$id = array('ID' => $this->uri->segment(3));
		$event = $this->tiket_model->get_data('event', $id);
		
		$data = array(
			'id'      => $event[0]['ID'],
			'qty'     => 1,
			'price'   => $event[0]['Price'], //<---------------
			'name'    => $event[0]['Event'],
			'option' => array()
		);
		$this->cart->insert($data);
		$this->index(); 
	}
	
	public function cart(){
		$this->load->view('home_cart_view'); 		
	}
	
	public function update(){
		$data = array(
			'rowid'      => $this->input->post('rowid'),
			'qty'        => $this->input->post('qty')
		);
	
		$this->cart->update($data);
		redirect('home/cart');
	}
	
	public function hapus(){
		$data = array(
			'rowid' => $this->uri->segment(3),
			'qty'   => 0
		);
		
		$this->cart->update($data);
		$this->cart();
	}
	
	public function bio(){
		$this->load->view('bio_view'); 		
	}

	public function bio_simpan(){
		//penyimpanan melalui session 		
		$newdata = array(
			'name'  => $this->input->post('name'),
			'email'     => $this->input->post('email')
		);

		$this->session->set_userdata($newdata);	//set session 	
		$this->invoice();		
	}	
	
	public function invoice(){
		//amnbil session  
		$name = $this->session->userdata('name');
		$email = $this->session->userdata('email');
		
		if ($cart = $this->cart->contents()){ //session cart
			foreach ($cart as $item){
				$data = array(
					'name' => $name,
					'email' => $email,
					'id' => $item['id'],
					'qty' => $item['qty'],
					'price' => $item['price']);					
				$this->tiket_model->set_data('invoice', $data);							
			}			
		}
		session_destroy(); //membuang session
		$this->load->view('invoice_view');		
	}
}
?>